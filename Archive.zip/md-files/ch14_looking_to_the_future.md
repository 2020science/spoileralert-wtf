# Chapter 14: Looking to the Future

*From Films from the Future: The Technology and Morality of Sci-Fi Movies by Andrew Maynard*

---

“Don’t panic.”
—The Hitchhiker’s Guide to the Galaxy

As I’m writing this, I’m looking out over the Firth of Clyde, from
the Scottish island of Arran. I first came here nearly thirty-four years
ago, in 1984, and it’s been an occasional getaway for me ever since.
Over this time, there have been changes, but the island still has that
comfortable feel of a place largely untouched by the frenetic pace
of modern innovation. As if to remind me of this, I’ve been traveling
along crumbling roads over the past few days, in a rental car that
modern automotive technologies seem to have completely bypassed,
while grappling with patchy Wi-Fi and even patchier cell-phone
coverage. It all feels a long way from the cutting-edge technologies
that have threaded through the previous chapters.
As an outsider, Arran still feels to me as if it belongs to a previous
age. Take away the intermittent internet and cellular phone system,
and to my off-islander eyes, I could still be in 1984. Yet I find this
strangely comforting. Despite sitting here wrapping up a book
on the profound changes that emerging technologies are likely to
bring about, it gives me hope that there’s life outside the frenzied
technological pace at which we sometimes seem to be living our
collective lives. And it affirms my belief that happiness lies not in
the latest technology, but in the more basic things of life, like food,
shelter, warmth, and good company.
Yet there’s a part of me that knows that these dreams of a slower,
more pleasant past are a sentimental illusion. Much as I enjoyed my
few days of potholed roads, rickety transportation, and intermittent
internet connections, I suspect that there are plenty of permanent
residents on Arran who have very different opinions about how
things are there. Despite the siren-call of nostalgia for a simpler,
less technologically complex time, the reality is that emerging

technologies, when developed and used responsibly, can and do
improve lives in quite powerful ways. There are far too many people
in today’s world who are living disadvantaged lives because they
don’t have access to technologies that could make them better, and I
worry that, if we’re tempted to start renouncing technologies from a
position of privilege, we risk denying too many people without the
same privileges the chance to make their own decisions. I would go
so far as to say that we have an obligation to explore new ways of
using science and technology to improve the world we’re living in
and the lives people lead.
This is an obligation, though, that comes with some tremendous
responsibilities. These include working hard to ensure the
technologies we develop benefit people without harming them.
But they also include learning how to live responsibly in a world
that, through our own drive to invent and to innovate, is constantly
changing.
These are tough challenges, and they’re ones that it’s all too easy to
leave to “experts” to grapple with. Yet I fear that this is, in itself, an
abdication of responsibility. Some of the technological challenges we
are facing are so profound, so life-changing, that the questions they
raise are ones that we cannot afford to leave solely to people like
scientists, innovators, and politicians to answer. The reality is that,
if we want to thrive in the technology-driven future we’re creating,
and we want to equip our children, and our children’s children, to
do the same, we all need to be able to wrap our collective heads
around what’s coming our way and how it might affect us. This is no
mean feat, though. It’s one that will require a journey of discovery
that uncovers the often-hidden links between ourselves and our
technologies, and how we can nudge them toward the future we
want, rather than one that someone else decides for us.
Through this book, I’ve set out to show how science fiction movies
can help point the way along this journey, flawed as they are.
As I’ve been researching and writing it, I’ve developed a deeper
appreciation of how the movies here can expand our appreciation
of the complex relationship between technology and society, not
because they are accurate or prescient, but precisely because they
are not tethered to scientific accuracy or to realistic predictions of
the future. It’s their creativity, and dare I say it, their entertainment
value, that helps open our eyes to seeing the world in new ways
which, when seasoned with feet-on-the-ground thinking, can help us
better understand what innovating responsibly means.

In 1978, the British Broadcasting Corporation first broadcast
Douglas Adams’ original radio series The Hitchhiker’s Guide to the
Galaxy. The Hitchhiker’s Guide quickly gained a cult following and
introduced millions of listeners to the fictional guide of the title. In
2005—four years after Adams’ death—The Hitchhiker’s Guide was
given the Hollywood treatment. It wasn’t the best movie ever made,
truth be told. But with its irreverent look at life in a complex galaxy,
and an even more complex society, it does provide a fitting bookend for this particular journey.
I am, I must confess, a great admirer of the skill with which Adams
creatively melded together odds and ends of ideas from very
different places to create new ones in his work. He was, of course,
well known for his often-absurd humor. But beyond the humor
(especially in the book and radio series), The Hitchhiker’s Guide
provides a remarkably astute commentary on our relationship with
technology. More importantly, though, the fictional “Hitchhikers
Guide to the Galaxy,” on which the series/book/film is based,
has the words “Don’t Panic” inscribed in large friendly letters on
its cover.
In today’s socially and technologically complex world, this is sage
advice. Of course, we shouldn’t be complacent—far from it. Without
a doubt, there are deep pitfalls on the road before us as we build
our technological future. As we’ve seen in the preceding chapters,
there are a multitude of ways in which we can well and truly make

Yet, for all their usefulness, there are dangers in getting too
wrapped up in science fiction movies as we think about the future.
Moviemakers draw on what we can imagine now, based on what
we already know; they cannot invent what’s yet to be discovered.
And in most movies, science and technology are simply devices
that are used to keep a human-centric plot moving along. This is
precisely why they excel at revealing insights into our relationship
with technology. But at the same time, it makes them a poor guide
to the technology itself, unless, like here, they’re used as a steppingoff point for exploring new and emerging developments. There is
another danger, though, and this is that, without a good dose of
scientific facts and social realism, science fiction movies can leave
us with a misplaced impression that we’re careering toward a
hopelessly dystopian technological future, and there’s not a lot we
can do about it.

a mess of things if we don’t think about what we’re doing. And yet,
I’m optimistic enough to believe that we have the collective ability to
develop new technologies in ways that work for us, not against us.
And here, “Don’t Panic” is as good a piece of advice as any.
There are, of course, many problems that we cannot solve with
science and technology on their own. Just like you can’t buy love
and happiness with money alone, you can’t simply “science” your
way to them either. But if we’re smart about it, we can use science
and technology to make love and happiness—and the many other
things that are important to us—that much easier to achieve. If we
can keep a clear head about us, and don’t fall prey to panic, or
become so enamored by the tech itself that we become blind to its
potential downsides, we have a decent chance of building a better
future together by developing and using emerging technologies in
ways that do more good than harm.
Because of this, I feel the words “Don’t Panic” are particularly apt
here. There is, though, another passing resemblance between this
book and Adams’ fictional Hitchhiker’s Guide to the Galaxy, and this
is the way that neither claims to be a comprehensive, infallible, allencompassing guide.
Adams’ Hitchhiker’s Guide to the Galaxy—a sort of Lonely Planet
guide for galactic travelers who are looking for a great time on a low
budget—doesn’t even pretend that it can reveal and explain the vast
complexity of the galaxy to its readers. Instead, it focuses on what
galactic hitchhikers really need to know, like how to get from A to
B while having a good time, how to avoid getting killed, and where
to get the best drinks. This, of course, is a long way removed from
this book. Yet, when I started to write it, two things quickly became
very clear. The first was that, for most people, what they really
want when looking for a guide to the future is something that helps
them get from A to B while having a good time, how to avoiding
getting killed, and where to get the best drinks. The second thing
was that no one ever reads an overlong, overweight, and utterly
incomprehensible guide.
Sadly, this book fails miserably on the “where to get the best drinks”
front. But I’d like to think that the preceding chapters, and the
movies they’re based on, have taken you on an interesting journey,
and one that provides at least a glimpse of how we can work toward
creating a technologically sophisticated future, while not creating
more problems than we solve on the way.

Rather, I set out to focus on how we think about technological
innovation, society, and the future, while exploring some intriguing,
but by no means comprehensive, developments on the way. And by
drawing on the imagination and creativity of science fiction movies,
I hope this book achieves this. It may not teach you how “deep
learning” works, or the intricacies of CRISPR-cas9 gene editing. But
the journey it covers, starting with Jurassic Park and de-extinction,
and ending with Contact and the search for extraterrestrial life, has
hopefully left you with a new appreciation for how science and
technology intersect and intertwine with society, and how, working
together, we can help use this to build a future that everyone
benefits from.

That said, much like its galactic counterpart, the book is a very
incomplete guide. Over the past few years, I’ve had the privilege
of being one of the contributors to the annual list of Top Ten
Emerging Technologies published by the World Economic Forum,
and I can safely say that, out of the seventy emerging technologies
we’ve highlighted to date, there are only a handful that appear
here. There are no self-driving cars in this book, and no advanced
nuclear reactors. There’s no precision medicine, or hydrogenpowered vehicles, or quantum computing. And there’s absolutely no
mention of blockchain. The reason, of course, is that the world of
technological innovation is so vast, so complex, and so fast-moving
that any guide that attempted to explain everything would end up
achieving nothing.
