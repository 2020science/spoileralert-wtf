# Chapter 3: Never Let Me Go — A Cautionary Tale of Human Cloning

*From Films from the Future: The Technology and Morality of Sci-Fi Movies by Andrew Maynard*

---

“Who’d make up stories as horrible as that?”
—Ruth

## Sins of Futures Past
In 2002, the birth of the first human clone was announced. Baby Eve
was born on December 26, 2002, and weighed seven pounds. Or so
it was claimed.
The announcement attracted media attention from around the world,
and spawned story after story of the birth. Since then, no proof has
emerged that baby Eve was anything other than a publicity stunt.
But the furor at the time demonstrated how contentious the very
idea of creating living copies of people can be.
There’s something about human cloning that seems to jar our
sense of right and wrong. It instinctively feels—to many people,
I suspect—as if it’s not quite right. Yet, at the same time, there’s
something fascinating about the idea that we might one day be
able to recreate a new person in our own likeness, or possibly
“resurrect” someone we can’t bear to lose—a child who’s passed,
or a loved relative. There’s even the uneasy notion that maybe, one
day, we could replicate those members of society who do the work
we can’t do, or don’t want to—a ready supply of combat personnel,
maybe, or garbage collectors. Or even, possibly, living, breathing
organ donors.
As it turns out, cloning humans is really difficult. It’s also fraught
with ethical problems. But this hasn’t stopped people trying, despite
near-universal restrictions prohibiting it.

You could be forgiven for feeling a little skeptical at this point.
Raël’s stories and beliefs come across as fantastical and delusional,
at least when they’re boiled down to their bare bones. But they
offer a window into the world of cloning that bizarrely echoes some
of the more mainstream ideas of transhumanists, and even some
technology entrepreneurs. They also create an intriguing canvas
on which to begin exploring the moral dilemmas presented in the
movie Never Let Me Go.

Never Let Me Go was never intended as a science fiction movie.
Its scriptwriter (and the author of the novel the movie’s based
on), Kazuo Ishiguro, was interested in what it means to live a
meaningful life, especially if that life is short and limited. Ironically,
the setting he used to explore this was a society that has discovered
the secret of a long and disease-free life. But the technology this
secret depends on is a program of human cloning, developed for no
purpose other than to allow the clones’ organs to be harvested when
the appropriate time came to keep others alive and healthy.
To Ishiguro, the clones were simply a plot device. Nevertheless, the
characters he created and the circumstances of their lives reveal a
dark side of how technologies like cloning can, if not used ethically
and responsibly, lead to quite devastating discrimination and abuse.
Never Let Me Go is set in a fictitious England in the 1970s to 1990s.
On the surface, it reminds me of the England I grew up in; the
settings, the people, and the culture all have a nostalgic familiarity to
them. But, unlike the England I remember, there’s something deeply
disturbing under the surface here. What unfolds is a heart-wrenching

Never Let Me Go: The Cautionary Tale of Human Cloning

On December 27, 2002, Brigitte Boisselier, a scientist working
for the organization Clonaid, announced that a cloned baby girl,
Eve, had been delivered by cesarian section to a thirty-one-yearold woman. Clonaid was founded in 1997 with the express aim
of cloning humans. But the company’s mission was far more
ambitious than this. The organization had its roots in the ideas and
teachings of one-time racing car test-driver, and subsequently selfproclaimed religious leader, Claude Vorilhon. Vorilhon, who later
renamed himself Raël and went on to establish the Raëlian religious
movement, believes that we are the creations of a “scientifically
more advanced species.” These aliens—the “Elohim”—have, he
claims, discovered the secret of immortality. And the key to this is,
apparently, cloning.

story about dignity, rights, and happiness, and what it means to have
value as a person. And because the movie is not focused on the
technology itself, but on the lives it impacts, it succeeds in providing
a searing insight into the social and moral risks of selling our
collective souls as we unquestionably embrace the seeming promise
of new technological capabilities.
At the center of Never Let Me Go are three young people, bound
together by a common experience. The story starts with them
as young children, at what looks at first glance like an exclusive
private school in the English countryside. They seem like ordinary
kids, with all the usual joys, pains, and intrigues that accompany
childhood. Except that these children are different.
As the movie unfolds, we begin to learn that these particular
students have been “bred.” They don’t have parents. They don’t even
have full names. Instead, they’re destined to give their short lives
for others as part of the National Donor Program, “donating” their
organs as they become young adults until, around the third or fourth
donation, they will “complete” and die on the operating table.
As the students get older, they are made increasingly aware of their
fate. They’re taught that they need to look after their bodies, that
this is their purpose in life—that their role is to die so others can
live. And most of them accept this fate.
Yet, despite their being treated as a commodity by the society
they’re created to serve, we begin to learn that not everyone
is comfortable with this. Their principal, Miss Emily (Charlotte
Rampling), is concerned about the ethics of the National Donor
Program. But, as we discover, she is less concerned about the
existence of the program than about how it’s run. She wants to find
evidence supporting her gut feeling that her students should be
treated as people, rather than walking organ donors. It turns out that
her school, Hailsham was set up as a progressive establishment to
explore whether these clones have that (apparently) quintessential
indicator of humanity, a “soul.” This, from the perspective of Miss
Emily and her supporters, is essential in determining whether the
students are worthy of being treated with the dignity and respect
afforded other members of the human race.
Against this backdrop, a deeply moving story of love, empathy, and
meaning plays out. Ultimately, the three clones we follow become
a yardstick of what constitutes “being human” against which their
creators are measured.

As the three children grow toward adulthood, they begin to hear
talk of a “deferment program,” a means of delaying the start of their
donations. It’s rumored that, if a couple can show that they truly
love each other, they can request a deferment from donating. This
would provide them with a short stay of execution before they give
up their organs and ultimately die in the process. And, according
to rumor, Miss Emily, their former principal at Hailsham, has some
influence here.
As they enter adulthood, the three young people move on from
the small community they live in together, and lose touch. Kathy
becomes a “carer,” looking after other donors as they move toward
completion. But some years after the three of them have gone their
separate ways, she runs across Ruth. Ruth is recovering from a
donation which hasn’t gone well, and Kathy steps in as her carer.
As the two rekindle their old relationship, they reconnect with
Tommy, who has also begun his donations. Ruth has been keeping
track of both Tommy and Kathy, in part because she is wracked with
guilt about how she treated them. She admits that she was jealous of
the deep bond between Tommy and Kathy when the three of them
were together and, because of this, stole Tommy away from Kathy.
As she nears completion, Ruth’s guilt becomes all-consuming. To try
to set things right, she provides Kathy and Tommy with what she
believes is the key to the rumored deferment program.
Ruth completes on her next donation, and after her death, Kathy
checks out the information she passed on about deferment. Ruth has
given her the address of a woman simply known as Madame, who
used to visit the now-closed Hailsham, and is possibly the person
one needs to approach to be admitted into the rumored program.
Filled with hope, Kathy and Tommy decide to visit her and request a
deferment. But there is a problem.

Never Let Me Go: The Cautionary Tale of Human Cloning

Standing at the core of Never Let Me Go is the relationship between
Kathy (played as a child by Izzy Meikle-Small, and as an adult by
Carey Mulligan), a kind, empathetic young woman trying to make
sense of her life, and Tommy (Charlie Rowe/Andrew Garfield),
a troubled young man whom she cares deeply for. Then there is
Ruth (Ella Purnell/Keira Knightly), a sometime-friend of Kathy and
Tommy’s who desperately wants to fit in with those around her, and
who selfishly robs those close to her of what’s precious to them as
she does.

While at Hailsham, the students were encouraged to express
themselves through art. Periodically, Madame visited the school and
selected the best of what they’d created. Kathy and Tommy deduce
that Madame holds the key to deferment, and convince themselves
that the way Madame tells whether two donors are truly in love
is through their art. The trouble is that Tommy never had any art
selected by Madame. It seems that their fragile hope is about to be
dashed because Tommy didn’t do enough when he was younger to
prove his worth.
Despite this, the two lovers think they see a way forward. Tommy
starts afresh developing his art portfolio, so he has something (he
believes) to demonstrate his “worthiness,” and the two of them set
out to visit the address provided by Ruth. Yet, on getting there, the
couple are devastated to discover that Madame has no ability to
grant a deferment; she never did.
It turns out that Madame and Miss Emily were working as a team
at Hailsham, but not to seek out evidence for true love. Rather, they
were using the students’ art to determine if they had souls, if they
had human qualities worth valuing beyond a working body and
healthy organs.
The two women earnestly wanted to find a way to show that these
children were capable of human feelings, and that they had validity
and worth beyond the organs they were carrying. Yet for all their
moral angst, Madame and Miss Emily turn out to be all mouth and
no backbone. They lament Kathy and Tommy’s plight. But they
also dash their fragile hopes, claiming there’s nothing they can do
to help.
As Kathy and Tommy return to the care home that night, Tommy
calmly asks Kathy to stop the car, and gets out. The whole weight
of the despair and injustice he’s carrying crushes down on him, as
he screams and weeps uncontrollably for the hope and the future
that society has robbed him of. In that one stark, revealing moment,
Tommy shows the full depth of his humanity, and he throws into
sharp relief the inhumanity of those who have sacrificed him to the
gods of their technology.
As Tommy and Ruth complete, and Kathy becomes a donor herself,
we realize that asking whether they have souls was the wrong
question. We’re left in no doubt that these young people deserve
respect, and dignity, and autonomy, and kindness, irrespective of
what they have achieved. And we realize that, through them, the

Never Let Me Go is a movie that delves deeply into the questionable
morality of convenient technologies. It’s also a movie that challenges
us to think about how we treat others, and what separates humanity
from inhumanity. But before we get there, it’s worth diving deeper
into the technology that underpins the unfolding story we’re
presented with: cloning.

## Cloning
On July 5, 1996, Dolly the sheep was born. What made Dolly
unusual was that she didn’t have regular biological parents. Rather,
she was grown from a cell that came from a single animal.
Dolly the sheep was the first successful clone of a domesticated
animal from an adult cell. And the proof that this was possible shot
the possibility of cloning from science fiction to science fantasy
almost overnight.
In Dolly’s case, the DNA from an ordinary, or somatic, cell—not
a reproductive cell or stem cell—was injected into an unfertilized
egg that had had its nucleus removed. This “clone egg” was then
electrically shocked into starting to divide and grow, after which it
was implanted in the uterus of a third sheep.
Dolly was born healthy and lived for nearly seven years before she
was put down due to increasingly poor health. But the legacy of
the experiment she was a part of lives on. What her birth and life
demonstrated without a shadow of doubt is that it’s possible to grow
a fully functioning animal from a single cell taken from an organ,
and presumably to keep on doing this time and time again.
It’s easy to see the attraction of cloning large animals, at least on the
surface. Loved pets could be reproduced, leading to a never-ending
cycle of pup to adult and back to pup. Prize livestock could be
duplicated, leading to large herds of prime cattle, or whole stables
of thoroughbreds. Rare species could be preserved. And then there
are people. Yet cloning human from scratch is harder than it might
at first seem.

Never Let Me Go: The Cautionary Tale of Human Cloning

society that created the technology that produced them has been
judged, and found wanting.

In July 2016, there was a flurry of articles marking the twentieth
anniversary of Dolly’s birth. In one of these, bioethicist Hank Greely
astutely pointed out just how hard cloning still is, even after two
decades of work: “Cats: easy; dogs: hard; mice: easy; rats: hard;
humans and other primates: very hard.”[^18] The trouble is, while the
concept of cloning is pretty straightforward, biology rarely is.
The basic idea behind cloning is to remove the DNA from a
healthy non-reproductive cell, insert it into a viable egg cell, and
then persuade this to develop into a fully functional organism that
is identical to the original. The concept is seemingly simple: the
DNA in each cell contains the genetic code necessary to create a
new organism from scratch. All that’s needed to create a clone is
to convince the DNA that it’s inside a fertilized egg, and get it to
behave accordingly. As it turns out, though, this is not that easy.
DNA may contain all the right code for creating a new life, but
getting it to do this is tricky.
This trickiness hasn’t stopped people from experimenting, though,
and in some cases succeeding. And as a result, if you really want
to, you can have your dog cloned,[^19] or pay a company to create for
you a clone-herd of cattle.[^20] And there continues to be interest in
cloning humans. But before we even get to the technical plausibility
of whether we can do this, there are complex ethical challenges
to navigate.

Despite advances in the science of cloning, the general consensus
on whether we should allow humans to be cloned seems to be
“no,” at least at the moment, although this is by no means a
universally accepted position. In 2005, the General Assembly of
the United Nations adopted a “Declaration on Human Cloning”
whereby “Member states were called on to adopt all measures
necessary to prohibit all forms of human cloning inasmuch as
they are incompatible with human dignity and the protection of

This concern over human reproductive cloning seems to run deep.
Certainly, it’s reflected in a number of the positions expressed
within the UN Declaration and is a topic of concern within plenty
of popular articles on cloning. The thought of being able to grow
people at will from a few cells feels to many people to be unnatural
and dangerous. It also raises tough questions around potential
misuse, which is something that Never Let Me Go focuses our
attention on rather acutely.
In 2014, the online magazine io9 published an article on nine
“unexpected outcomes of human cloning,”[^22] keeping the fascination
we have with this technology going, despite the deep moral
concerns surrounding it. These unexpected outcomes included
ownership of clones (will someone else own the patent on your
body?), the possibility of iterative improvements over generations
(essentially a DNA software upgrade on each cloning), and raising
the dead (why not give Granny a new lease on life?). The article is
admittedly lighthearted. But it does begin to dig into the challenges
we’ll face if someone does decide to buck the moral trend and start
to turn out human facsimiles. And the reality is that, as biomedical
science progresses, this is becoming increasingly feasible.
Admittedly, it’s incredibly difficult at the moment to reproduce
people. But this is not always going to be the case. And as the
possibility comes closer, we’re going to face some increasingly tough
choices as a society.
Yet despite the unease around human cloning, there are some
people who actively suggest the idea shouldn’t be taken off the
table completely. In 1997, not too long after Dolly’s birth, a group of
prominent individuals put their name to a “Declaration in Defense

Never Let Me Go: The Cautionary Tale of Human Cloning

human life.”[^21] Yet this was not a unanimous declaration: eightyfour members voted in favor, thirty-four against, and thirty-seven
abstained. One of the more problematic issues was how absolute
the language was in the declaration. A number of those member
states that voted against it expressed their opposition to human
reproductive cloning where a fully functioning person results
(human reproductive cloning), but wanted to ensure that the way
remained open to therapeutic cloning, where cloned cells remain in
lab cultures.

of Cloning and the Integrity of Scientific Research.”[^23] Signatories
included co-discoverer of DNA Francis Crick, scientist and writer
Richard Dawkins, and novelist Kurt Vonnegut.
This Declaration acknowledges how knotty an ethical issue human
cloning is, and it recognizes up front the need for appropriate
guidelines. But where it differs from the later UN Declaration is that
its authors suggest that human cloning isn’t as ethically or morally
fraught as some people make out. In fact, they state:

“We see no inherent ethical dilemmas in cloning non-human
higher animals. Nor is it clear to us that future developments
in cloning human tissues or even cloning human beings will
create moral predicaments beyond the capacity of human
reason to resolve. The moral issues raised by cloning are neither
larger nor more profound than the questions human beings
have already faced in regards to such technologies as nuclear
energy, recombinant DNA, and computer encryption. They are
simply new.”

The Declaration doesn’t go so far as to suggest that human
reproductive cloning should proceed. But it does say that decisions
should be made based on science and reasoned thinking, and
it cautions scientists and policy makers to ensure “traditionalist
and obscurantist views do not irrelevantly obstruct beneficial
scientific developments.”
In other words, the declaration’s authors are clear in their conviction
that religious beliefs and mystical thinking should not be allowed to
stand in the way of scientific progress.
Ironically, one of the easiest places to find a copy of the “Declaration
in Defense of Cloning…” is, in fact, in a treatise that is infused with
religious beliefs and mystical thinking: Claude Vorilhon’s monograph
Yes to Human Cloning.[^24]

Vorilhon, better known these days by his adopted name of Raël,
published the monograph Yes to Human Cloning as a wide-ranging

Despite its rather unusual provenance, I’d recommend reading
Yes to Human Cloning, although I would suggest you approach it
with a critical mind and a good dose of skepticism. Raël is a clear
and engaging writer, and he makes his case with some eloquence
for adopting emerging technologies like nanotechnology and
artificial intelligence. In fact, if parts of this work were selectively
published with the “I talk to aliens” bits removed, you’d be forgiven
for thinking they came from a more mainstream futurist like Ray
Kurzweil, or even a technology entrepreneur like Elon Musk. I’d go
so far as to say that, when stripped of the really weird stuff, Raël’s
vision of the future is one that would appeal to many who see
humans as no more than sophisticated animals and technology as a
means of enhancing and engineering this sophistication.
In Raël’s mind, human cloning is a critical technology in a three-step
program for living forever.25 Some transhumanists believe the route
to longevity involves being cryogenically frozen until technology
advances to the point at which it can be used to revive and repair
them. Others seek longevity through technological augmentation.
Raël, though, goes one step further and suggests that the solution
to longevity is disposable bodies. And so, we have his three-step
program to future immortality, which involves (1) developing the
ability to clone and grow a replacement human body, (2) developing
the technology to accelerate the rate of growth, so an adult body
takes weeks rather than years to produce, and (3) developing
the technology to upload our minds into cyberspace, and then
download them into a fresh new (and probably upgraded) cloned
version of yourself.
Stupendously complex (not to mention, implausible) as this would
be, there are people around who think that parts of this plan are
feasible enough that they’re already working on it, as we’ll see in
later chapters. Raël’s plan would, naturally, require the ability to
grow a body outside of a human womb. But this is already an active
area of research, as we saw in chapter two. And, as we’ll explore in
later chapters, neuroscientists and others are becoming increasingly
excited by the prospect of capturing the essence of the human mind,
to the point that they can reproduce at least part of it in cyberspace.

This must surely be the ultimate “three-step program.”

Never Let Me Go: The Cautionary Tale of Human Cloning

treatise on technological innovation and humanity’s future. And at its
center is his rationale for why cloning is not only acceptable, but in
fact essential to us achieving our destiny as a species.

What particularly fascinates me here is that, beneath the Raëlian
mysticism and UFO weirdness, this movement is playing with ideas
that are increasingly garnering mainstream attention. And this means
that, even if we won’t be growing bodies in our basements anytime
soon, we have to take the possibility of human reproductive cloning
seriously. And this means grappling not only with the ethics of the
process itself, but also the ethics of how we chose to treat and act
toward those clones we create.

## Genuinely Human?
Louise Brown was born in the year 1978. What made Louise unique
was that she was the world’s first child to be conceived via in vitro
fertilization (IVF).
I was thirteen at the time, and not especially interested the bigger
world of technology innovation around me (that would come
later). But Louise’s birth stuck with me, and it was because of a
conversation I remember having with my mother around about
this time.
I don’t remember the details. But what I do remember is my mother
wondering if a child conceived in a test tube would be like other
people as they grew up—most especially, whether they would have
a soul.[^26]
Of course, Louise and all the millions of other IVF-conceived
babies that have been born over the years, are just as complete as
every other of the seven billion plus people living on this planet.
There is nothing about the mode of conception that changes the
completeness or the value of a person.
This should be self-evident. But as a quick Google search reveals,
there are still more people than I would have imagined who
are worried about the “humanity” of those conceived outside of
biological intercourse.
One example in particular stood out to me as I was writing this
chapter. In 2015, a contributor with the alias “Marie18” wrote on the
website Catholic Answers Forum:

So, pretty much what I’m asking is if we have souls or not. I
know in my heart that I do, but I’ve read some very upsetting
things on the internet by Christians and Catholics.[^27]

It’s heart-rending that anyone should even have to ask this question.
But it suggests that the premise of Never Let Me Go isn’t as farfetched as it might at first seem.
In Never Let Me Go, society absolves itself of the guilt of treating
children as a commodity by claiming that clones are somehow
less than human, that they are merely human-created animals and
no more. It’s a convenient lie—much like the one underpinning
the Precrime program we’ll encounter in Minority Report (chapter
four)—that allows the non-clones in the movie to tell themselves
it’s okay to grow clones for their organs and kill them when
they’re done.
What the movie so eloquently illustrates is that, far from being
somehow less than human, Tommy and Kathy and Ruth are as
human as anyone else in the society they live in. In this respect,
Never Let Me Go challenges us to think critically about what defines
our humanity and our “worth” as Homo sapiens.

What gives us worth, or value, as individuals, is an increasingly
important question as we develop technologies that enable us
to not only redesign ourselves, but also use what we know of
ourselves to develop new entities entirely. Human enhancement
and augmentation, the merging of human and cybernetic systems,
artificial intelligence, and cloning, all potentially threaten our
sense of identity. And yet we stand at a point in human history
where, more than at any previous time, we have the means to alter
ourselves and redesign what we want to be.

Never Let Me Go: The Cautionary Tale of Human Cloning

I learned today that my parents had me and my twin through
IVF, and I just feel kind of devastated. Do IVF babies have
souls? I would think so, but I just feel really uneasy that I was
conceived through science, and I wasn’t in God’s plan for my
parents.

In this emerging world, “different” is no longer simply something
we’re born with, but something we have the means to create. In
fact, it’s not too much of a stretch to suggest that our growing
technological abilities are heading toward a point where they
threaten to fundamentally challenge our identity as a species. And as
they do this, they are forcing us to reconsider—just as Never Let Me
Go does—what “human” means in the first place.
On December 10, 1948, the United Nations General Assembly
proclaimed the Universal Declaration of Human Rights.[^28] In its first
Article, this historic declaration states, “All human beings are born
free and equal in dignity and rights. They are endowed with reason
and conscience and should act towards one another in a spirit
of brotherhood.”
This, and the following twenty-nine Articles of the Declaration,
establish a moral and ethical basis for attributes we as a society
believe are important: equality, dignity, freedom, and security for all
people. But the Declaration doesn’t actually define what “human”
means.[^29]
Ask most people, and I have a feeling that the answer to “What is
it to be human?” would include attributes such as being self-aware,
being able to think and reason, having human form, being the
product of a female egg and a male sperm, or being a member of
a distinct biological species.[^30] These seem a not-too-bad starting
point as characteristics that we can measure or otherwise identify.
But they begin to look a little weak as we develop the ability to
reengineer our own biology. They also leave the door open for
people or “entities” that don’t easily fit the definition conveniently
being labeled as “less than human,” including those that don’t fit
convenient but arbitrary norms of physical and intellectual ability, or
who are simply perceived as being “different.”
This is not a new challenge, of course. Ironically, one of our
defining features as a species is an unerring ability to label those

We can surely learn from cases of socially unacceptable behavior
that have led to slavery, repression, discrimination, and other forms
of abuse. If we cannot, cloning and other technologies that blur our
biological identity are likely to further reveal the darker side of our
“humanity” as we attempt to separate those we consider worthy of
the thirty articles of the Universal Declaration of Human Rights from
those we don’t.
But in a future where we can design and engineer people in ways
that extend beyond our biological origins, how do we define what
being “human” means?
As it turns out, this is a surprisingly hard question to answer.
However you approach it, and whatever intellectual arguments you
use, it’s too easy to come down to an “us versus them” position,
and to use motivated reasoning to justify why our particular brand
of humanity is the right one. The trouble is, we’re conditioned to
recognize humanity as being “of us” (and whoever the “us” is gets to
define this). And we have a tendency to use this arbitrary distinction
to protect ourselves from those we consider to be “not us.”
The possibility of human reproductive cloning begins to reveal
the moral complexities around having the ability to transcend our
biological heritage. If we do eventually end up cloning people,
the distinction between “like us” (and therefore fully human) and
“not like us” (and therefore lacking basic human rights) is likely to
become increasingly blurred. But this is only the start.
In 2016, a group of scientists launched a ten-year project to
construct a synthetic human genome from scratch. This is a project
that ambitiously aims to construct all three billion base pairs of the
human genome in the laboratory, from common lab chemicals, and
create the complete blueprint for a fully functioning person with no
biological parents or heritage. This is the first step in an ambitious
enterprise to create a completely synthetic human being within 20
years; a living, breathing person that was designed by computer and
grown in the lab.[^31] If successful (and I must confess that I’d be very

Never Let Me Go: The Cautionary Tale of Human Cloning

we don’t like, or feel threatened by, as “less than human.” Through
some of the most sordid episodes in human history, distinctions of
convenience between “human” and “not human” have been used to
justify acts of atrocity; it’s easier to justify inhuman acts when you
claim that the focus of them isn’t fully human in the first place.

surprised if this can be achieved within twenty years), this project
will make the moral challenges of cloning seem like child’s play. At
least a clone has its origins in a living person. But what will we do if
and when we create a being who is like you and me in every single
way, apart from where they came from?
This may seem like a rather distant moral dilemma. But it is
foreshadowed by smaller steps toward having to rethink what we
mean by “human.” As we’ll see in later chapters, mind-enhancing
drugs are already beginning to blur the lines between what are
considered “normal” human abilities, and what tip us over into
technologically-enhanced “abnormal abilities.” Movies like Ghost
in the Shell (chapter seven) push this further by questioning the
boundaries between machine-enhanced humans and machines with
human tendencies. And when we get to the movie Transcendence
(chapter nine), we’re looking at a full-blown melding between
a human mind and a machine. In each of these cases, using
technologies to alter people or to create entities with human-like
qualities challenges us with two questions in particular: what does
it mean to be “human”? And what are the rights and expectations of
entities that don’t fit what we think of as human, yet are capable of
thinking and feeling, that have dreams and hopes, and are able to
suffer pain and loss?
The seemingly easy way forward here is to try to develop a
definition of humanity that encompasses all of our various future
creations. But I’m not sure that this will ultimately succeed, if only
because this still reflects a way of thinking that mentally divides
the world into “human” and “not human.” And with this division
comes the temptation to endow the former with all the rights that
come with being human and an assumed right to exploit the latter,
simply because we don’t think of them as being part of the same
privileged club.
Rather, I suspect that, at some point, we will need to transcend
the notion of “human” and instead focus on rights, and an
understanding of “worth” and “validity” that goes far beyond what
we bestow on ourselves as Homo sapiens.
Making this transition will not be easy. But we’ve already begun to
make a start in how we think about rights as they apply to other
species, and the responsibility we have toward them. Increasingly,
there is an awareness that being human does not come with a
God-given right to dominate, control, and indiscriminately use other

In other words, our measures of what has worth inevitably come
down to what has worth to us.
This is of course quite understandable. As a species, we are at the
top of the food chain, and we’re biologically predisposed to do
everything we can to stay there. But this doesn’t help lay down a
moral framework for how we behave toward entities that do not fit
our ideas of what is worthy.
This will be a substantial challenge if and when we create entities
that threaten our humanness, and by implication, the power we
currently wield as a species. For instance, if we did at some point
produce human clones, they would be our equals in terms of
biological form, function, awareness and intellect. But we would
know they were different, and would have to decide how to respond
to this. We could, of course, grant them rights; we might even
declare them to be fully human, or at least honorary members of the
human club. But here’s the kicker: What right would we have to do
this? What natural authority do we have that allows us to decide the
fate of creations such as these? This is a deeply challenging question
when it comes to entities that are almost, but not quite, the same
as us. But it gets even more challenging when we begin to consider
completely artificial entities such as computer- or robot-based
artificial intelligence.
We’ll come back to this in movies like Minority Report (chapter
four) and Ghost in the Shell (chapter seven). But before we do,
there’s one other insight embedded in Never Let Me Go that’s worth
exploring, and that’s how easily we fall into justifying technologies
that devastate a small number of lives, because we tell ourselves we
cannot live without them.

Never Let Me Go: The Cautionary Tale of Human Cloning

species to our own advantage. But how we translate this into action
is difficult, and is often colored by our own ideas of worth and
value. In effect, we easily slip into defining what is important by
what we think of as being important. For instance, we place greater
value on species that are attractive or interesting to us; on animals
and plants that inspire awe in us. And we value species more that
we believe are important to the sustainability of our world, or what
we perhaps arrogantly call “higher” species, meaning those that are
closer relatives to us on the evolutionary ladder. And we especially
value species that demonstrate human-like intelligence.

## Too Valuable to Fail?

Whichever way you look at it, the society within which Never Let Me
Go is situated doesn’t come off that well. To most other people in the
movie, the clones are seen as little more than receptacles for growing
living organs in, waiting for someone to claim them.
In contrast, the staff at Hailsham are an anomaly, a blip in the social
conscience that is ultimately drowned out by the irresistible benefits
the Human Donor Program offers. But the morality behind this
anomaly is, not to put too fine a point on it, rather insipid. Madame,
Miss Emily, and others appear to care for the clones, and want to
prove that they have human qualities and are therefore worthy of
something closer to “human” dignity. But ultimately, they give way to
resignation in a society that sees the donor program as too valuable
to end.
As Tommy and Kathy visit Miss Emily to plead for their lives by
showing that they are truly in love, we learn that they never had
a hope. Miss Emily, Madame, and others were striving to appease
their consciences by showing that the clones had a soul, that they
were human. Maybe they thought they could somehow use this to
change how the clones were treated. But the awful truth is that Miss
Emily never believed she could change what society saw the clones
as—living caretakers of organs for others. There never was a hope in
her mind that the children would be treated as anything other than a
commodity. Certainly, she cared for them. But she didn’t care enough
to resist an atrocity that was unfolding in front of her eyes.
All of this—the despair, the injustice, the inhumanity, the cruelty—
pours out of Tommy as he weeps and rages in the headlights of
Kathy’s car. And, standing with him, we know in our hearts that this
society has sold itself out to a technology that rips people’s lives and
dreams away from them, so that those with the privilege of not being
labeled “clone” can live longer and healthier lives.
This, to me, is a message that stays with me long after watching Never
Let Me Go—that if we are not careful, technology has the power to
rob us of our souls, even as it sustains our bodies, not because it
changes who we are, but because it makes us forget the worth of
others. It’s a message that’s directly relevant to human cloning, should
we ever develop this technology to the point that it’s widely used.
But it also applies to other technologies that blur our definitions of
“worth,” including the use of technologies that claim to predict how
someone will behave, as we’ll see in our next movie: Minority Report.


[^18]: Greely was being quoted in an article by Sharon Begley in Business Insider (“Here’s why we’re still not cloning humans, 20 years after Dolly the sheep.” July 5, 2016. http://www.businessinsider.com/can-you-clone-a-human-2016-7). He also noted that the world’s best polo team at the time (the horses) was made up of clones.

[^19]: Although, as New York Magazine pointed out in September 2016, “Paying $100,000 to Clone Your Dog Won’t Give You Your Dog Back.” The original link in the book is dead, but this is a good replacement: https://www.discovermagazine.com/just-because-you-can-clone-your-dog-doesnt-mean-they-will-be-the-same-46091

[^20]: The US Food and Drug Administration approved the sale of cloned animals and their young for food in 2008—just in case you were wondering.

[^21]: General Assembly Adopts United Nations Declaration on Human Cloning by vote of 84-34-37. March 8, 2005. Accessible at http://www.un.org/press/en/2005/ga10333.doc.htm

[^22]: George Dvorsky (2014), “9 Unexpected Outcomes Of Human Cloning.” io9, July 17 2014. http://io9.gizmodo.com/9-unexpected-outcomes-of-human-cloning-1606556772

[^23]: Admiraal, P., Ardila, R., & Berlin, I. (1997). Declaration in defense of cloning and the integrity of scientific research. Free Inquiry, 17(3), 11-12.

[^24]: Raël (2001) “Yes to Human Cloning.” https://www.amazon.com/Yes-Human-Cloning-Rael/dp/1903571057

[^26]: Talking to my mother when writing the book, she readily admitted that her view of the world has changed quite substantially over the past few decades. This is definitely not the sort of question she would have be asking in 2018.

[^27]: “Do IVF babies have souls?” Posted on the website Catholic Answers Forums, January 2015, https://web.archive.org/web/2018/https://forums.catholic.com/t/do-ivf-babies-have-souls/387786

[^28]: “The United Nations Universal Declaration of Human Rights.” https://www.un.org/en/about-us/universal-declaration-of-human-rights

[^29]: There are many parallels between this discussion of how we think about and define what it is to be “human,” and discussions around the meaning and nature of “personhood.” In some ways of thinking, the idea of personhood encapsulates a set of attributes that are not uniquely tied to Homo sapiens, and as a result transcend the distinction between “human” and “non-human.” This opens the way to exploring the rights and responsibilities of personhood as it extends to animals, artificial intelligence, and other non-human life forms. However, the question remains: Who decides what the defining attributes of “personhood” are, and if it’s us that decide this, what are the chances that we’re bringing our own pro-human biases to the table?

[^30]: In among these answers, I suspect there would also be a fair number of people who included “having a soul.”

[^31]: Boeke, J. D., et al. (2016). “The Genome Project-Write.” Science 353(6295): 126-127. http://doi.org/10.1126/science.aaf6850
