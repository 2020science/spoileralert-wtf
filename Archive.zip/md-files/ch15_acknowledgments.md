# Acknowledgments

*From Films from the Future: The Technology and Morality of Sci-Fi Movies by Andrew Maynard*

---

Over the years, I’ve had the privilege of talking and working with
many amazing people whose ideas and insights have informed
and inspired me, and helped guide this book. Sadly, they are too
numerous to list, but I am deeply indebted to them, as I am to the
script writers, directors, actors and producers of the movies featured
here, and who provided the creative inspiration for Films from the
Future. Without them, this book would not exist. In addition to
these founts of knowledge and inspiration, this book wouldn’t have
become what it did without an army of friends and colleagues who
graciously allowed me to ply them with early drafts, and equally
graciously provided critical feedback that reduced my chances of
making a fool of myself: Michael Bennett, Diana Bowman, Michael
Burnam-Fink, Ariel Conn, Lindy Elkins-Tanton, Joey Eschrich, Jane
Flegal, Elizabeth Garbee, Sarah Geren, Jess Givens, Darshan Karwat,
Lauren Keeler, Eric Kennedy, Jon Klane, Sean McAllistair, Nicole
Mayberry, Philip Maynard, Stephen Maynard, Becca Monteleone,
Anna Muldoon, Hilary Sutcliffe, Lucy Tournas, and Jamie Winterton.
Of course, having offered their services this time round, they’re
going to find it hard to escape being drafted in to do the same
with the sequel to Films from the Future. I also want to gratefully
acknowledge the wonderful encouragement, guidance, and support,
of my editor Hugo Villabona and the whole team at Mango—without
whom this book would probably still be no more of a reality that
some of the sci-fi futures it explores. And of course, none of this
would have been possible without the support and encouragement
of my family, and especially my wife, Clare.
Thank you.
