## Never Let Me Go (2010)

**Directed by Mark Romanek | Based on the novel by Kazuo Ishiguro**

In an alternate version of Britain, medical science has achieved something remarkable: a way to cure almost every disease and extend human life far beyond its natural span. The catch is that this miracle depends on a program of human cloning. Children are bred, raised, and eventually harvested for their organs so that "normal" people can live longer, healthier lives. The film follows three young clones, Kathy, Tommy, and Ruth, from childhood through their short, constrained lives, as they grapple with love, friendship, jealousy, and the dawning realization of what they were created for.

### Spoiler Alert

This page discusses major plot points from Never Let Me Go, including its devastating ending. The film is a slow, quiet gut-punch, and knowing what is coming does not diminish its power. But if you want to experience it fresh, watch it first.

### What This Chapter Explores

Never Let Me Go was never intended as a science fiction film. Its author, Kazuo Ishiguro, was interested in what it means to live a meaningful life, especially one that is short and limited. The cloning technology is simply a plot device. And yet, precisely because the film is not focused on the technology itself but on the lives it impacts, it succeeds in providing one of the most searing explorations of the social and moral risks of emerging biotechnology in any medium.

The chapter uses the film to explore the science of cloning, starting with the birth of Dolly the sheep in 1996 and tracing the path toward the possibility of human reproductive cloning. While cloning humans remains extraordinarily difficult and almost universally prohibited, the science is advancing. And as it does, the ethical questions the film raises become increasingly urgent. What rights would a cloned human have? Would society treat them as fully human? Or would it find convenient ways to classify them as something less, as the society in the film does?

What makes Never Let Me Go so powerful as a lens for these questions is how it reveals the human capacity for moral self-deception. The society in the film does not see itself as monstrous. It has simply decided that the benefits of the cloning program are too valuable to give up, and it has constructed a set of comfortable lies to justify this. The clones are treated as less than human, not because there is evidence that they are, but because it is convenient to believe so. The film's most devastating insight is that even the people who care about the clones, who try to prove that they have souls and deserve dignity, ultimately lack the courage to challenge the system.

This connects to a broader theme the chapter explores: the concept of technologies that become "too valuable to fail." Once a society becomes dependent on a technology, even one with deeply troubling ethical dimensions, the pressure to maintain it can overwhelm moral objections. The chapter draws parallels to real-world technologies where convenience and benefit make us reluctant to confront uncomfortable truths about how they affect others.

The chapter also uses the film to open up one of the book's most important questions: what does it mean to be human? As technologies like cloning, genetic engineering, artificial intelligence, and human augmentation advance, the boundaries of "human" are becoming increasingly blurred. Never Let Me Go challenges us to think about how we define worth and dignity, and whether those definitions will hold up in a future where the line between "natural" and "engineered" is no longer clear.

### Key Technologies

- [Cloning and reproductive biology](https://spoileralert.wtf/md-files/est_cloning.md) — The science of creating genetically identical organisms, from Dolly the sheep to the prospect of human reproductive cloning
- [Organ harvesting and transplantation](https://spoileralert.wtf/md-files/est_organ_transplantation.md) — The technologies and ethics of using biological systems to supply replacement organs

### Ethical and Responsibility Themes

- [Human dignity and what makes us human](https://spoileralert.wtf/md-files/rei_human_dignity.md) — How we define worth, identity, and the boundaries of humanity
- [Too valuable to fail](https://spoileralert.wtf/md-files/rei_too_valuable_to_fail.md) — When the benefits of a technology make us unwilling to confront its moral costs
- [Could we? Should we?](https://spoileralert.wtf/md-files/rei_could_we_should_we.md) — The gap between technical capability and ethical wisdom
- [Informed consent and autonomy](https://spoileralert.wtf/md-files/rei_informed_consent.md) — The right to understand and choose what happens to your own body and life
- [Deception, manipulation, and convenient lies](https://spoileralert.wtf/md-files/rei_deception_manipulation.md) — How societies construct comfortable narratives to justify harmful technologies

### Navigating the Future

- [Everyone has a role to play](https://spoileralert.wtf/md-files/ntf_everyone_has_a_role.md) — Why decisions about powerful technologies cannot be left to experts alone
- [The human dimension](https://spoileralert.wtf/md-files/ntf_human_dimension.md) — Keeping human lives and experiences at the center of how we think about technology

### Post-2018 Developments

- [The AGI Debate: Consciousness, Existential Risk, and the Doomer Spectrum](https://spoileralert.wtf/md-files/p18_agi_debate.md) — Is artificial general intelligence — AI that matches or exceeds human cognitive abilities across…
- [Brain Organoids and Neural Tissue of Uncertain Moral Status](https://spoileralert.wtf/md-files/p18_brain_organoids.md) — A small clump of human neural tissue sits in a dish, firing in patterns that resemble the EEG…
- [CRISPR Babies, Embryo Selection, and Heritable Gene Editing](https://spoileralert.wtf/md-files/p18_crispr_babies_embryo_selection.md) — In November 2018, the same year Films from the Future was published, Chinese scientist He Jiankui…
- [Digital Resurrection, Grief Tech, and AI Companions of the Dead](https://spoileralert.wtf/md-files/p18_grief_tech.md) — A mother in South Korea stands in a VR studio, wearing a headset, reaching toward a child-sized…
- [Xenotransplantation](https://spoileralert.wtf/md-files/p18_xenotransplantation.md) — In January 2022, surgeons at the University of Maryland Medical Center transplanted a genetically…

### Emerging Questions

- [Should an algorithm be allowed to decide whether I get a job, a loan, or parole?](https://spoileralert.wtf/md-files/ceq_algorithmic_decisions.md) — Algorithms already make or heavily influence these decisions
- [Should an algorithm be allowed to be my boss?](https://spoileralert.wtf/md-files/ceq_algorithmic_management.md) — The question sounds absurd on first pass and becomes more serious with each example
- [Should we let parents choose their children's genes?](https://spoileralert.wtf/md-files/ceq_choosing_childrens_genes.md) — This is not a science fiction question
- [What do we owe a lump of brain tissue in a dish?](https://spoileralert.wtf/md-files/ceq_moral_status_neural_tissue.md) — It is a strange question to have to ask in this decade

### Discussion Questions

* How realistic is the story that evolves in Never Let Me Go?
* What are the pros and cons of cloning humans?
* What makes someone genuinely "human"?
* Are there technologies that exist now that are so useful that they are too big to be allowed to fail?
* How do societies come to accept practices that, from the outside, seem clearly immoral?
* What is the difference between asking whether someone has a soul and asking whether they deserve dignity?
* Can you think of real-world technologies whose costs are borne by people most of us never see?

### Continue Exploring

Never Let Me Go shares its concern with human dignity and identity with [Ghost in the Shell](https://spoileralert.wtf/md-files/movies_ghost_in_the_shell.md) and [Ex Machina](https://spoileralert.wtf/md-files/movies_ex_machina.md), both of which push the question of what counts as "human" in different directions. The theme of technologies that become too valuable to challenge also surfaces in [Elysium](https://spoileralert.wtf/md-files/movies_elysium.md) and [The Day After Tomorrow](https://spoileralert.wtf/md-files/movies_day_after_tomorrow.md).

## Further Reading

- [What Can Sci-Fi Movies Teach Us About Technology Ethics? (Future of Being Human)](https://www.futureofbeinghuman.com/p/want-to-get-smart-about-technology-ethics-these-sci-fi-movies-can-help-3cebedf29c9c) — Andrew Maynard explores how science fiction films, including Never Let Me Go, serve as powerful tools for thinking through the ethical dimensions of emerging technologies. The piece makes the case that fiction can illuminate moral questions in ways that textbooks and policy papers cannot.
- [Never Let Me Go on IMDb](https://www.imdb.com/title/tt1334260/) — The complete film page for Mark Romanek's 2010 adaptation of Kazuo Ishiguro's novel, featuring Carey Mulligan, Andrew Garfield, and Keira Knightley. The film's quiet, devastating portrayal of cloned humans raised for organ harvesting remains one of cinema's most emotionally powerful explorations of bioethics.
- [Cloning and Stem Cell Research (Nature)](https://www.nature.com/articles/d41586-018-01835-z) — Nature's reporting on the science of cloning provides the real-world scientific context for the film's premise. From Dolly the sheep to advances in therapeutic cloning and stem cell therapies, this coverage traces the trajectory of a technology that continues to raise profound ethical questions about human identity and dignity.
- [Organ Transplantation (World Health Organization)](https://www.who.int/health-topics/transplantation) — The WHO's overview of organ transplantation addresses the global shortage of donor organs and the ethical frameworks governing transplant medicine. This resource connects directly to the film's central horror: a society that solves the organ shortage by creating human beings specifically to be harvested.
