# Post-2018 Developments

*Domain hub for spoileralert.wtf — based on Films from the Future by Andrew Maynard*

---

## About This Domain

*Films from the Future* was published in 2018. The technologies and ethical frameworks it explores have not stood still. This domain covers technologies and developments that have emerged or accelerated significantly since the book was written — areas where the book's thinking tools remain directly relevant even though the specific developments came after it went to press.

Each page introduces the technology or development, explains where things stand, and connects back to the book's frameworks, ethical themes, and films. These are not updates to the book — they are extensions of it, demonstrating that the questions the book asks are more urgent now than when they were first written.

This domain works in close partnership with the [Complex Emerging Questions](https://spoileralert.wtf/md-files/domain_complex_emerging_questions.md) domain, which uses many of these developments as raw material for the contested dilemmas they raise. It also connects extensively to the original [Emerging Science and Technology](https://spoileralert.wtf/md-files/domain_emerging_science_and_technology.md) pages, the ethical themes in [Responsible and Ethical Innovation](https://spoileralert.wtf/md-files/domain_responsible_and_ethical_innovation.md), and the thinking frameworks in [Navigating the Future](https://spoileralert.wtf/md-files/domain_navigating_the_future.md).

---

## Topic Pages

### Cluster: AI, Agents, and Generative Systems

#### 1. Large Language Models, Frontier AI, and Agentic Systems
- **Page:** [p18_llms_frontier_ai.md](https://spoileralert.wtf/md-files/p18_llms_frontier_ai.md)
- **Scope:** The trajectory from GPT-2 to frontier models, the shift to agentic AI and systems of agents, use in education, and the copyright/IP upheaval. The defining technology development since the book was published.
- **Cross-links:** [Artificial Intelligence](https://spoileralert.wtf/md-files/est_artificial_intelligence.md); [Superintelligence](https://spoileralert.wtf/md-files/est_superintelligence.md); [Permissionless Innovation](https://spoileralert.wtf/md-files/rei_permissionless_innovation.md); [Hype vs. Reality](https://spoileralert.wtf/md-files/ntf_hype_vs_reality.md)

#### 2. Deepfakes, Synthetic Media, and the Crisis of Authenticity
- **Page:** [p18_deepfakes_synthetic_media.md](https://spoileralert.wtf/md-files/p18_deepfakes_synthetic_media.md)
- **Scope:** AI-generated video, audio, and images indistinguishable from real. Detection efforts and their limits. Legitimate creative uses. The social consequences when evidence becomes unreliable.
- **Cross-links:** [Deception, Manipulation, and Convenient Lies](https://spoileralert.wtf/md-files/rei_deception_manipulation.md); [Science, Belief, and Ways of Knowing](https://spoileralert.wtf/md-files/ntf_science_belief.md); [The Role of Art and Culture](https://spoileralert.wtf/md-files/ntf_role_of_art_culture.md)

#### 3. Autonomous Weapons and Lethal Autonomous Systems
- **Page:** [p18_autonomous_weapons.md](https://spoileralert.wtf/md-files/p18_autonomous_weapons.md)
- **Scope:** Military AI, drone warfare, autonomous targeting, the "meaningful human control" debate. The gap between deployment speed and governance.
- **Cross-links:** [Could We? Should We?](https://spoileralert.wtf/md-files/rei_could_we_should_we.md); [Informed Consent and Autonomy](https://spoileralert.wtf/md-files/rei_informed_consent.md); [Risk and Innovation](https://spoileralert.wtf/md-files/ntf_risk_innovation.md)

#### 4. Autonomous Vehicles
- **Page:** [p18_autonomous_vehicles.md](https://spoileralert.wtf/md-files/p18_autonomous_vehicles.md)
- **Scope:** Self-driving cars from Waymo to Tesla to Zoox. Where the technology actually stands vs. the promises made. Liability, labor, and how much risk society should accept from machines.
- **Cross-links:** [Artificial Intelligence](https://spoileralert.wtf/md-files/est_artificial_intelligence.md); [Automation and Robotics](https://spoileralert.wtf/md-files/est_automation.md); [Hype vs. Reality](https://spoileralert.wtf/md-files/ntf_hype_vs_reality.md); [Permissionless Innovation](https://spoileralert.wtf/md-files/rei_permissionless_innovation.md)

#### 5. AI-Generated Art, Creative AI, and the IP Question
- **Page:** [p18_ai_generated_art.md](https://spoileralert.wtf/md-files/p18_ai_generated_art.md)
- **Scope:** AI tools that produce art, music, writing. Labor displacement, the authorship question, and whether existing IP frameworks can survive when machines create.
- **Cross-links:** [The Role of Art and Culture](https://spoileralert.wtf/md-files/ntf_role_of_art_culture.md); [Power, Privilege, and Access](https://spoileralert.wtf/md-files/rei_power_privilege_access.md); [Corporate Responsibility](https://spoileralert.wtf/md-files/rei_corporate_responsibility.md)

### Cluster: Biology, Health, and Human Futures

#### 6. mRNA Vaccines and Rapid Vaccine Platforms
- **Page:** [p18_mrna_vaccines.md](https://spoileralert.wtf/md-files/p18_mrna_vaccines.md)
- **Scope:** COVID-19 vaccines as proof of concept, the mRNA platform's broader potential, the speed-of-development vs. speed-of-trust tension, and the equity question.
- **Cross-links:** [Genetic Engineering](https://spoileralert.wtf/md-files/est_genetic_engineering.md); [Dual-Use Research and Biosecurity](https://spoileralert.wtf/md-files/rei_dual_use_biosecurity.md); [Too Valuable to Fail](https://spoileralert.wtf/md-files/rei_too_valuable_to_fail.md)

#### 7. CRISPR Babies, Embryo Selection, and Heritable Gene Editing
- **Page:** [p18_crispr_babies_embryo_selection.md](https://spoileralert.wtf/md-files/p18_crispr_babies_embryo_selection.md)
- **Scope:** He Jiankui's 2018 experiment, preimplantation genetic testing with whole-genome sequencing, polygenic embryo scoring, and the moving line between therapy and design.
- **Cross-links:** [Genetic Engineering](https://spoileralert.wtf/md-files/est_genetic_engineering.md); [Cloning](https://spoileralert.wtf/md-files/est_cloning.md); [Could We? Should We?](https://spoileralert.wtf/md-files/rei_could_we_should_we.md); [Human Dignity](https://spoileralert.wtf/md-files/rei_human_dignity.md)

#### 8. Aging, Anti-Aging, and Biopreservation
- **Page:** [p18_aging_anti_aging.md](https://spoileralert.wtf/md-files/p18_aging_anti_aging.md)
- **Scope:** The longevity field's explosion — senolytics, reprogramming factors, epigenetic clocks. Organ biopreservation technologies. The equity question of who gets to live longer.
- **Cross-links:** [Bioprinting and Organ Regeneration](https://spoileralert.wtf/md-files/est_bioprinting.md); [Power, Privilege, and Access](https://spoileralert.wtf/md-files/rei_power_privilege_access.md); [Hype vs. Reality](https://spoileralert.wtf/md-files/ntf_hype_vs_reality.md)

#### 9. Lab-Grown Meat and Cellular Agriculture
- **Page:** [p18_lab_grown_meat.md](https://spoileralert.wtf/md-files/p18_lab_grown_meat.md)
- **Scope:** Cultured meat, precision fermentation, state-level bans, the cultural identity of food, lobbying dynamics. A case where social resistance rivals the technical challenge.
- **Cross-links:** [Synthetic Biology](https://spoileralert.wtf/md-files/est_synthetic_biology.md); [Technological Convergence](https://spoileralert.wtf/md-files/ntf_technological_convergence.md); [Corporate Responsibility](https://spoileralert.wtf/md-files/rei_corporate_responsibility.md)

#### 10. Pandemic Preparedness and Biosurveillance
- **Page:** [p18_pandemic_preparedness.md](https://spoileralert.wtf/md-files/p18_pandemic_preparedness.md)
- **Scope:** COVID-19 as a case study for the book's biosecurity and complex systems frameworks. The lab-leak debate, gain-of-function governance, and new biosurveillance infrastructure.
- **Cross-links:** [Gain-of-Function Research](https://spoileralert.wtf/md-files/est_gain_of_function.md); [Dual-Use Research and Biosecurity](https://spoileralert.wtf/md-files/rei_dual_use_biosecurity.md); [Complexity and Unintended Consequences](https://spoileralert.wtf/md-files/ntf_complexity_chaos.md)

### Cluster: Brain, Mind, and Behavior

#### 11. Commercial Brain-Computer Interfaces
- **Page:** [p18_commercial_bcis.md](https://spoileralert.wtf/md-files/p18_commercial_bcis.md)
- **Scope:** Three distinct approaches — invasive (Neuralink), endovascular (Synchron), non-invasive (wearables). Moving from research labs to consumer products.
- **Cross-links:** [Brain-Computer Interfaces](https://spoileralert.wtf/md-files/est_brain_computer_interfaces.md); [Human Augmentation](https://spoileralert.wtf/md-files/est_human_augmentation.md); [Informed Consent](https://spoileralert.wtf/md-files/rei_informed_consent.md); [Human Dignity](https://spoileralert.wtf/md-files/rei_human_dignity.md)

#### 12. Psychedelics and Therapeutic Neuroscience
- **Page:** [p18_psychedelics_therapeutic.md](https://spoileralert.wtf/md-files/p18_psychedelics_therapeutic.md)
- **Scope:** Psilocybin, MDMA-assisted therapy, the decriminalization wave, venture capital in psychedelics, and the indigenous knowledge question.
- **Cross-links:** [Smart Drugs and Cognitive Enhancement](https://spoileralert.wtf/md-files/est_smart_drugs.md); [Power, Privilege, and Access](https://spoileralert.wtf/md-files/rei_power_privilege_access.md); [Informed Consent](https://spoileralert.wtf/md-files/rei_informed_consent.md)

#### 13. AI, Mental Health, and Behavioral Influence
- **Page:** [p18_ai_mental_health.md](https://spoileralert.wtf/md-files/p18_ai_mental_health.md)
- **Scope:** AI companion apps, therapeutic chatbots, algorithmic content curation shaping mood and behavior. The adolescent mental health crisis. When the algorithm knows you are vulnerable.
- **Cross-links:** [Predictive Algorithms](https://spoileralert.wtf/md-files/est_predictive_algorithms.md); [Deception, Manipulation, and Convenient Lies](https://spoileralert.wtf/md-files/rei_deception_manipulation.md); [The Human Dimension](https://spoileralert.wtf/md-files/ntf_human_dimension.md)

### Cluster: Environment and Earth Systems

#### 14. Active Geoengineering Proposals
- **Page:** [p18_active_geoengineering.md](https://spoileralert.wtf/md-files/p18_active_geoengineering.md)
- **Scope:** Stratospheric aerosol injection moving from theory to small-scale experiments, marine cloud brightening, the governance void. What was conceptual in the book is now contested reality.
- **Cross-links:** [Geoengineering](https://spoileralert.wtf/md-files/est_geoengineering.md); [Could We? Should We?](https://spoileralert.wtf/md-files/rei_could_we_should_we.md); [Intergenerational Responsibility](https://spoileralert.wtf/md-files/rei_intergenerational_responsibility.md)

#### 15. Carbon Removal and Climate Tech
- **Page:** [p18_carbon_removal.md](https://spoileralert.wtf/md-files/p18_carbon_removal.md)
- **Scope:** Direct air capture, nature-based solutions, carbon markets, the scale problem. The tension between "we need everything" and the risk of distraction from emission cuts.
- **Cross-links:** [Climate Science](https://spoileralert.wtf/md-files/est_climate_science.md); [Resilience and Adaptation](https://spoileralert.wtf/md-files/ntf_resilience_adaptation.md); [Hype vs. Reality](https://spoileralert.wtf/md-files/ntf_hype_vs_reality.md)

### Cluster: Data, Surveillance, and Governance

#### 16. Social Credit, Algorithmic Scoring, and Automated Gatekeeping
- **Page:** [p18_algorithmic_scoring.md](https://spoileralert.wtf/md-files/p18_algorithmic_scoring.md)
- **Scope:** China's social credit system, algorithmic scoring in hiring, lending, insurance, and content moderation. The book's Minority Report frameworks made real.
- **Cross-links:** [Predictive Algorithms](https://spoileralert.wtf/md-files/est_predictive_algorithms.md); [Surveillance, Privacy, and Control](https://spoileralert.wtf/md-files/rei_surveillance_privacy_control.md); [Informed Consent](https://spoileralert.wtf/md-files/rei_informed_consent.md)

#### 17. Facial Recognition and Biometric Surveillance
- **Page:** [p18_facial_recognition.md](https://spoileralert.wtf/md-files/p18_facial_recognition.md)
- **Scope:** Deployment by police, airports, retailers. Accuracy disparities. The ban-vs-regulate debate. The normalization of biometric identification and the shrinking space for anonymity.
- **Cross-links:** [Ubiquitous Surveillance](https://spoileralert.wtf/md-files/est_surveillance.md); [Surveillance, Privacy, and Control](https://spoileralert.wtf/md-files/rei_surveillance_privacy_control.md); [Everyone Has a Role](https://spoileralert.wtf/md-files/ntf_everyone_has_a_role.md)

### Cluster: Convergence and Frontier

#### 18. Quantum Computing
- **Page:** [p18_quantum_computing.md](https://spoileralert.wtf/md-files/p18_quantum_computing.md)
- **Scope:** What quantum computers actually are vs. the hype. Where they stand. What they would actually change — cryptography, drug discovery, materials science. A clean hype vs. reality case study.
- **Cross-links:** [Hype vs. Reality](https://spoileralert.wtf/md-files/ntf_hype_vs_reality.md); [Technological Convergence](https://spoileralert.wtf/md-files/ntf_technological_convergence.md); [Surveillance, Privacy, and Control](https://spoileralert.wtf/md-files/rei_surveillance_privacy_control.md)

#### 19. The AGI Debate: Consciousness, Existential Risk, and the Doomer Spectrum
- **Page:** [p18_agi_debate.md](https://spoileralert.wtf/md-files/p18_agi_debate.md)
- **Scope:** Whether AGI is imminent, distant, or impossible. The x-risk community, the doomer/accelerationist spectrum, claims about AI consciousness. The book's frameworks applied: count the assumptions, don't panic, don't dismiss.
- **Cross-links:** [Superintelligence](https://spoileralert.wtf/md-files/est_superintelligence.md); [Hype vs. Reality](https://spoileralert.wtf/md-files/ntf_hype_vs_reality.md); [Could We? Should We?](https://spoileralert.wtf/md-files/rei_could_we_should_we.md); [Don't Panic](https://spoileralert.wtf/md-files/ntf_dont_panic.md)

#### 20. Synthetic Biology's Acceleration: AI-Designed Life and Biomanufacturing
- **Page:** [p18_synbio_acceleration.md](https://spoileralert.wtf/md-files/p18_synbio_acceleration.md)
- **Scope:** The convergence of AI and synthetic biology. AlphaFold and protein structure prediction. Generative models designing DNA sequences. Cloud labs and democratized bioengineering. Biosecurity implications when AI makes it easier to design organisms.
- **Cross-links:** [Synthetic Biology](https://spoileralert.wtf/md-files/est_synthetic_biology.md); [Gain-of-Function Research](https://spoileralert.wtf/md-files/est_gain_of_function.md); [Dual-Use Research and Biosecurity](https://spoileralert.wtf/md-files/rei_dual_use_biosecurity.md); [Technological Convergence](https://spoileralert.wtf/md-files/ntf_technological_convergence.md)

### Cluster: Biology, Moral Status, and the Substrate Question

#### 21. Brain Organoids and Neural Tissue of Uncertain Moral Status
- **Page:** [p18_brain_organoids.md](https://spoileralert.wtf/md-files/p18_brain_organoids.md)
- **Scope:** Lab-grown neural tissue, assembloids, organoid transplantation into other animals, the ISSCR governance gap, and the moral-status question the field has no agreed method for answering. The *Never Let Me Go* wrong-question framework applied.
- **Cross-links:** [Cloning](https://spoileralert.wtf/md-files/est_cloning.md); [Human Augmentation](https://spoileralert.wtf/md-files/est_human_augmentation.md); [Could We? Should We?](https://spoileralert.wtf/md-files/rei_could_we_should_we.md); [Too Valuable to Fail](https://spoileralert.wtf/md-files/rei_too_valuable_to_fail.md); [Human Dignity](https://spoileralert.wtf/md-files/rei_human_dignity.md)

#### 22. Biological Computing, Wetware, and Bio-Silicon Hybrids
- **Page:** [p18_biological_computing.md](https://spoileralert.wtf/md-files/p18_biological_computing.md)
- **Scope:** Cortical Labs' CL1 commercial biological computer, FinalSpark's neuron-powered platform, organoid intelligence as a research programme, DNA data storage. Computation on living human neurons, and the governance vacuum between AI, biomedical, and BCI regulation.
- **Cross-links:** [Technological Convergence](https://spoileralert.wtf/md-files/est_technological_convergence.md); [Artificial Intelligence](https://spoileralert.wtf/md-files/est_artificial_intelligence.md); [Mind Uploading](https://spoileralert.wtf/md-files/est_mind_uploading.md); [Hype vs. Reality](https://spoileralert.wtf/md-files/ntf_hype_vs_reality.md); [Permissionless Innovation](https://spoileralert.wtf/md-files/rei_permissionless_innovation.md)

#### 23. Xenotransplantation
- **Page:** [p18_xenotransplantation.md](https://spoileralert.wtf/md-files/p18_xenotransplantation.md)
- **Scope:** The Maryland pig-heart transplants (Bennett 2022, Faucette 2023), the Massachusetts General pig-kidney work, eGenesis and Revivicor as donor-pig infrastructure, PERV retrovirus risks, and the first FDA-cleared xenotransplant clinical trial. Animal-ethics questions the book's frameworks do not fully reach.
- **Cross-links:** [Organ Transplantation](https://spoileralert.wtf/md-files/est_organ_transplantation.md); [Genetic Engineering](https://spoileralert.wtf/md-files/est_genetic_engineering.md); [Synthetic Biology](https://spoileralert.wtf/md-files/est_synthetic_biology.md); [Too Valuable to Fail](https://spoileralert.wtf/md-files/rei_too_valuable_to_fail.md); [Human Dignity](https://spoileralert.wtf/md-files/rei_human_dignity.md); [Dual-Use Research and Biosecurity](https://spoileralert.wtf/md-files/rei_dual_use_biosecurity.md)

#### 24. Consumer Genomics and the Privatization of the Genome
- **Page:** [p18_consumer_genomics.md](https://spoileralert.wtf/md-files/p18_consumer_genomics.md)
- **Scope:** 23andMe's 2025 bankruptcy and the $305M sale of ~15M genetic profiles, GEDmatch and law-enforcement use, GINA's limits, polygenic risk scoring in mainstream medicine, and the family-consent problem. The canonical case of consent-under-one-regime-transferred-to-another.
- **Cross-links:** [Genetic Engineering](https://spoileralert.wtf/md-files/est_genetic_engineering.md); [Surveillance](https://spoileralert.wtf/md-files/est_surveillance.md); [Informed Consent](https://spoileralert.wtf/md-files/rei_informed_consent.md); [Surveillance, Privacy, and Control](https://spoileralert.wtf/md-files/rei_surveillance_privacy_control.md); [Corporate Responsibility](https://spoileralert.wtf/md-files/rei_corporate_responsibility.md)

### Cluster: Attention, Labor, and Life Online

#### 25. Algorithmic Labor and Algorithmic Management
- **Page:** [p18_algorithmic_labor.md](https://spoileralert.wtf/md-files/p18_algorithmic_labor.md)
- **Scope:** Amazon warehouse TOT tracking (and the French CNIL €32M fine), rideshare deactivation, Veena Dubal's research on algorithmic wage discrimination, workplace surveillance software, and the WGA 2023 contract as a precedent for negotiated AI limits in labor.
- **Cross-links:** [Automation](https://spoileralert.wtf/md-files/est_automation.md); [Predictive Algorithms](https://spoileralert.wtf/md-files/est_predictive_algorithms.md); [Surveillance](https://spoileralert.wtf/md-files/est_surveillance.md); [Surveillance, Privacy, and Control](https://spoileralert.wtf/md-files/rei_surveillance_privacy_control.md); [Power, Privilege, and Access](https://spoileralert.wtf/md-files/rei_power_privilege_access.md); [Risk Innovation](https://spoileralert.wtf/md-files/ntf_risk_innovation.md)

#### 26. Attention, Cognitive Sovereignty, and the Erosion of Deep Focus
- **Page:** [p18_attention_cognition.md](https://spoileralert.wtf/md-files/p18_attention_cognition.md)
- **Scope:** Gloria Mark's 47-second attention research, Johann Hari's *Stolen Focus* synthesis, Jonathan Haidt's contested *Anxious Generation* argument, cognitive offloading and the "Google effect." The inverse of *Limitless* — what if we're all taking an attention-shredding drug we didn't choose?
- **Cross-links:** [Smart Drugs and Cognitive Enhancement](https://spoileralert.wtf/md-files/est_smart_drugs.md); [AI, Mental Health, and Behavioral Influence](https://spoileralert.wtf/md-files/p18_ai_mental_health.md); [Deception, Manipulation, and Convenient Lies](https://spoileralert.wtf/md-files/rei_deception_manipulation.md); [Science, Belief, and Ways of Knowing](https://spoileralert.wtf/md-files/ntf_science_belief.md); [The Human Dimension](https://spoileralert.wtf/md-files/ntf_human_dimension.md)

#### 27. Digital Resurrection, Grief Tech, and AI Companions of the Dead
- **Page:** [p18_grief_tech.md](https://spoileralert.wtf/md-files/p18_grief_tech.md)
- **Scope:** HereAfter AI, StoryFile, Replika, the South Korean VR *Meeting You* documentary, the Joaquin Oliver AI avatar, California and Tennessee posthumous-likeness legislation, and the Cambridge "DDNR" (Do Not Digitally Resurrect) proposal. The cheap, available version of the transhumanist dream.
- **Cross-links:** [Deepfakes, Synthetic Media](https://spoileralert.wtf/md-files/p18_deepfakes_synthetic_media.md); [AI, Mental Health](https://spoileralert.wtf/md-files/p18_ai_mental_health.md); [Mind Uploading](https://spoileralert.wtf/md-files/est_mind_uploading.md); [Human Dignity](https://spoileralert.wtf/md-files/rei_human_dignity.md); [Informed Consent](https://spoileralert.wtf/md-files/rei_informed_consent.md); [Deception, Manipulation, and Convenient Lies](https://spoileralert.wtf/md-files/rei_deception_manipulation.md)

### Cluster: Space Systems and Planetary Futures

#### 28. Space Industrialization and Orbital Infrastructure
- **Page:** [p18_orbital_infrastructure.md](https://spoileralert.wtf/md-files/p18_orbital_infrastructure.md)
- **Scope:** Starlink's 9,000+ active satellites, Kessler syndrome as an active scenario, Vera Rubin Observatory and astronomy impact, the Outer Space Treaty's limits, ASAT weapons tests, and the absence of binding international debris governance.
- **Cross-links:** [Extraterrestrial Life](https://spoileralert.wtf/md-files/est_extraterrestrial_life.md); [Permissionless Innovation](https://spoileralert.wtf/md-files/rei_permissionless_innovation.md); [Power, Privilege, and Access](https://spoileralert.wtf/md-files/rei_power_privilege_access.md); [Corporate Responsibility](https://spoileralert.wtf/md-files/rei_corporate_responsibility.md); [Risk Innovation](https://spoileralert.wtf/md-files/ntf_risk_innovation.md); [Complexity and Unintended Consequences](https://spoileralert.wtf/md-files/ntf_complexity_chaos.md)

#### 29. Mars Settlement and the New Frontier Mythology
- **Page:** [p18_mars_settlement.md](https://spoileralert.wtf/md-files/p18_mars_settlement.md)
- **Scope:** SpaceX Starship's 2026 delay, the "Planet B" / civilisational-insurance framing, Kim Stanley Robinson's critique, the Antarctic-station alternative model, intergenerational commitment, and governance by launch provider. Resilience vs. lifeboat framing.
- **Cross-links:** [Extraterrestrial Life](https://spoileralert.wtf/md-files/est_extraterrestrial_life.md); [Intergenerational Responsibility](https://spoileralert.wtf/md-files/rei_intergenerational_responsibility.md); [Informed Consent](https://spoileralert.wtf/md-files/rei_informed_consent.md); [Corporate Responsibility](https://spoileralert.wtf/md-files/rei_corporate_responsibility.md); [Resilience and Adaptation](https://spoileralert.wtf/md-files/ntf_resilience_adaptation.md)

### Cluster: Energy Systems

#### 30. Fusion, SMRs, and the Energy Stack Underneath Everything
- **Page:** [p18_energy_transition.md](https://spoileralert.wtf/md-files/p18_energy_transition.md)
- **Scope:** NIF ignition (Dec 2022) and what "ignition" did and did not mean, Commonwealth Fusion / Helion / TAE private capital, NuScale's UAMPS collapse and post-collapse rebound, TerraPower's Natrium delays, AI data-center demand driving the Three Mile Island restart and the broader nuclear revival.
- **Cross-links:** [Geoengineering](https://spoileralert.wtf/md-files/est_geoengineering.md); [Climate Science and Complex Earth Systems](https://spoileralert.wtf/md-files/est_climate_science.md); [Active Geoengineering Proposals](https://spoileralert.wtf/md-files/p18_active_geoengineering.md); [Carbon Removal](https://spoileralert.wtf/md-files/p18_carbon_removal.md); [Hype vs. Reality](https://spoileralert.wtf/md-files/ntf_hype_vs_reality.md); [Too Valuable to Fail](https://spoileralert.wtf/md-files/rei_too_valuable_to_fail.md); [Intergenerational Responsibility](https://spoileralert.wtf/md-files/rei_intergenerational_responsibility.md)

---

## How This Domain Connects

This is one of six interconnected domains on spoileralert.wtf:

- **[Post-2018 Developments](https://spoileralert.wtf/md-files/domain_post_2018_developments.md)** (this file) — 30 technologies and developments that emerged or accelerated after the book was published
- **[Complex Emerging Questions](https://spoileralert.wtf/md-files/domain_complex_emerging_questions.md)** — 19 contested questions at the intersection of technology, society, and the future
- **[Emerging Science and Technology](https://spoileralert.wtf/md-files/domain_emerging_science_and_technology.md)** — 23 topic pages covering the technologies explored in and around the book
- **[Responsible and Ethical Innovation](https://spoileralert.wtf/md-files/domain_responsible_and_ethical_innovation.md)** — 13 cross-cutting ethical themes that recur across multiple chapters and technologies
- **[Navigating the Future](https://spoileralert.wtf/md-files/domain_navigating_the_future.md)** — 12 frameworks for thinking about technology and society
- **[The Movies](https://spoileralert.wtf/md-files/domain_the_movies.md)** — 12 film pages connecting each movie to the technologies and themes it illuminates

The full book text is available in [chapter files](https://spoileralert.wtf/md-files/ch01_in_the_beginning.md) (chapters 1–14 plus acknowledgments). For guidance on tone and approach when engaging with this material, see [usage_guidance.md](https://spoileralert.wtf/md-files/usage_guidance.md).
